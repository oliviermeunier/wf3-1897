#Todolist de la todolist :)

MARDI 
- [DONE] page d'accueil avec la liste des tâches
- [DONE] installer var-dumper avec Composer (gestionnaire de paquets)
- [DONE] remplir le formulaire en cas d'erreur
- [DONE] voir les sessions
- [DONE] ajouter un message flash lors de la création d'une tâche

MERCREDI
- correction fonctions flash messages
- factorisation des templates
- créer un front controller et un router (gestion des URLs) + arborescence
- formulaire de modification d'une tâche
- suppression d'une tâche
- signaler une tâche comme "terminée"
- [BONUS] créer des fonctions génériques pour exécuter des requêtes SQL

JEUDI
- intégrer le formulaire de création de compte 
- connexion / déconnexion utilisateur 
- relation user / task
- sécurité et autorisations